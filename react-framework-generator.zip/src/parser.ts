const context = {} as any;
const {q,paramCase} = context;

/**
 AST node type: ForStatement (see common node types)
 wildcard: *
 attribute existence: [attr]
 attribute value: [attr="foo"] or [attr=123]
 attribute regex: [attr=/foo.*\/]
 attribute conditons: [attr!="foo"], [attr>2], [attr<3], [attr>=2], or [attr<=3]
 nested attribute: [attr.level2="foo"]
 field: FunctionDeclaration > Identifier.id
 First or last child: :first-child or :last-child
 nth-child (no ax+b support): :nth-child(2)
 nth-last-child (no ax+b support): :nth-last-child(1)
 descendant: ancestor descendant
 child: parent > child
 following sibling: node ~ sibling
 adjacent sibling: node + adjacent
 negation: :not(ForStatement)
 matches-any: :matches([attr] > :first-child, :last-child)
 has: IfStatement:has([name="foo"])
 class of AST node: :statement, :expression, :declaration, :function, or :pattern
*/
const imports = q`
ImportDeclaration
`.map(
  i=>({
    clauses: q(i, 'ImportClause Identifier.name'),
    path: q(i, 'StringLiteral', 0),
    statement: i
  })
)

function getAttributes(el){
  // return el.attributes
  const isHtml = !/^[A-Z]/.test(el.tagName.getFullText())
  if(el.attributes){
    return el.attributes
    .properties
    .map(attr=>{
      let attrType, value;
      let name = attr.name
      
      if(q(attr, 'JsxElement').length){
        attrType = 'slot'
        value = attr.initializer.expression.expression
      }else if(attr.initializer.text){
        attrType = 'property'
        value = attr.initializer
      }else if(isHtml){
        if(name.getFullText().trim().startsWith('on')){
          attrType = 'event';
          value = attr.initializer
        }else if(name.getFullText().trim() === 'ref'){
          attrType = 'ref'
          value = attr.initializer.expression
        }else{
          attrType = 'binding'
          value = attr.initializer
        }
      }else {
        attrType = 'binding'
        value = attr.initializer
      }
      console.log(attrType)
      return {
        name: attr.name,
        type: attrType,
        value
      }
    })

  }
  return el
}
function getComponent(el){
  // return el
  if(!el){
    return null
  }
  
  if(el.children){
    return {
      name: el.openingElement.tagName,
      type: 'element',
      props: getAttributes(el.openingElement),
      children: el.children.map(getComponent)
    }
  }else if(el.text) {
    return {
      type: 'text',
      value: el
    }
  }else if (el.tagName){
    return {
      name: el.tagName,
      props: getAttributes(el),
      type: 'element',


    }
  }else if(el.expression){
    const expr = el.expression
    if(expr.condition){
      return {
        type: 'condition',
        ifCondition: expr.condition,
        whenTrue:getComponent(expr.whenTrue),
        whenFalse: getComponent(expr.whenFalse)

      }
    }else if(expr.operatorToken){
      return {
        type: 'condition',
        ifCondition: expr.left,
        whenTrue: getComponent(expr.right)
      }
    }else if (expr.expression){
      if(expr.arguments){
        return {
          type: 'loop',
          variable: expr.expression.expression,
          item: expr.arguments[0].parameters[0],
          index: expr.arguments[0].parameters[1],
          body: getComponent(expr.arguments[0].body)

        }
      }
      return {
        type: 'expression',
        value: expr.expression
      }
    }
    return el
  }
  
}
function getVariableCallInitial(v){
  return {
    name: v.name,
    value: v.initializer.arguments,
    type: v.initializer.typeArguments
  }
}
function getRefs(func){
  const allRefs = q(func, `
      VariableStatement:has(
        CallExpression:has(
          Identifier[escapedText="useRef"]
        )
      )`
    )
  const refs = []
  const elementRefs = allRefs.map(r=>({
    ...getVariableCallInitial(r.declarationList.declarations[0])
  })).filter(ref=>{
    const result = q`
    JsxAttribute JsxExpression>Identifier[
      escapedText="${
       ref.name.getText()}"
      ]
    `
    
    if(!result.length){
      refs.push(ref)
    }
    return result.length
    }
  )
  return {
    refs,
    elementRefs
  }

}
const component = q`FunctionDeclaration:has(ExportKeyword):has(DefaultKeyword)`
  .map(func=>({
    name: func.name,
    inputProps: q(func,`
      FunctionDeclaration>Parameter BindingElement
    `).map(el=>({
      name: el.name,
      defaultValue: el.initializer
    })),
    states: q(func, `
      VariableStatement:has(
        CallExpression:has(
          Identifier[escapedText="useState"]
        )
      )`
    ).map(s=>getVariableCallInitial(s.declarationList.declarations[0]))
    .map(s=> ({
      ...s,
      name: s.name.elements[0].name,
      setter: s.name.elements[1].name
    })),
    ...getRefs(func),
    
    methods: q(func, `
      FunctionDeclaration FunctionDeclaration
    `).map((method)=>{
      return {
        statement: method,
        name: method.name
      }
    }),
    render: getComponent(q(func, `
      ReturnStatement:has(JsxElement)
      >ParenthesizedExpression
      >JsxElement 
    `,0))
  }))[0]
const data = {
  componentsUsed: q`JsxOpeningElement
    >Identifier[escapedText=/^[A-Z]/]`
  .concat(q`JsxSelfClosingElement
    >Identifier[escapedText=/^[A-Z]/]`),
  component,
  imports,

}


export default data