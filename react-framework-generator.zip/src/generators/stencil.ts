//
const context = {} as any;
const {q,data,paramCase,refReplaceFactory} = context;
const {component: comp, ...ctx} = data
  const refReplace = refReplaceFactory({
    methods: {
      name: {
        find:(n)=>n,
        replace:(n)=>'this.'+n
      }
    },
    elementRefs: {
      name: {
        find:(n)=>n+'.current',
        replace:(n)=>'this.'+n+'.nativeElement'
      }
    },
    refs: {
      name: {
        find:(n)=>n+'.current',
        replace:(n)=>'this.'+n
      }
    },
    states: {
      name: {
        find:(n)=>n,
        replace:(n)=>'this.'+n
      },
      setter: {
        find: (n, ref)=>`${n}\\((.*?)\\)`,
        replace:(n,ref)=>`this.${ref.name.getFullText().trim()} = $1`
      }
    },
    inputProps: {
      name: {
        find:(n)=>n,
        replace:(n)=>'this.'+n
      },
    }
  }, comp)
  const angularProps = (props) => {
    return props.map(prop=>{
      switch(prop.type){
        case 'event':
          return `${prop.name.getFullText()
          .trim()}={${
            refReplace(prop.value.expression.getFullText())
          }}`
        case 'property':
          return `${prop.name.getFullText().trim()}${prop.value && `=${prop.value.getFullText()}`}`
        case 'binding': 
          return `${prop.name.getFullText().trim()}${prop.value && `={${refReplace(prop.value.expression.getFullText())}}`}`
        case 'ref':
          return `ref={(el)=>${refReplace(prop.value.getFullText())} = el}`
      }
    }).join(' ')
  }
  const blockToAngular = (tree)=>{
    return tree.map(el=>{
      switch(el.type){
        case 'element':
          if(el.children){
            return `
          <${paramCase(el.name.getFullText())} ${angularProps(el.props)}>
            ${blockToAngular(el.children)}
          </${paramCase(el.name.getFullText())}>`
          }else {
            return `<${paramCase(el.name.getFullText())} ${angularProps(el.props)}/>`

          }
        case 'text': 
          return el.value.getFullText() 
      }
    }).join('')
  }



export default `import { Component } from "@angular/core";
${ctx.imports
.filter(({path})=>path.text!=='react')
.filter(({clauses})=>{
  return !clauses.some(
  c=>!!ctx.componentsUsed.some(
    (co)=>c.getFullText().trim()===co.getFullText().trim()
  )
  )
})
.map(i=>i.statement.getFullText()).join('')}

@Component({
  tag: "${paramCase(comp.name.getText())}"
})
export class ${comp.name.getText()} {
  ${comp.elementRefs.map(({name})=>
   `private ${
     name.getFullText().trim()}: any | undefined;`)
     .join('\n')}
  ${comp.inputProps.map(({name, defaultValue})=>
    `@Prop() ${name.getFullText().trim()}: any ${defaultValue?`= ${defaultValue.getFullText()}`:''};`
  ).join('\n')}
  ${comp.states.map(({name, value})=>{
    return `${name.getFullText()} ${value[0]&&`= ${value[0].getFullText()}`}`}).join('\n')}
  ${comp.methods.map(m=>`${m.name.getFullText().trim()}=${refReplace(
      m.statement.getFullText().trim()
       .replace(/^function (.*?)\((.*?)\).*?{/, '($2) => {')
    )}`).join('\n')}
  render(){
    return (
      ${blockToAngular([comp.render])}
    )
  }
}
`